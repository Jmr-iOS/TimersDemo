//  ScheduledTimer.swift
//  TimerDemo
//
import UIKit

class ScheduledTimer: NSObject {
    
    var myVar: int = 4;
    
    override init() {

        super.init();
        
        myVar = 3;
     
        print("Init()!");
        
        return;
    }
}
